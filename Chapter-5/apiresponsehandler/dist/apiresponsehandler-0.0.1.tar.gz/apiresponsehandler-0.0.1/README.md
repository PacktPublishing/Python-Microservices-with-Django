
```
## Usage

from apiresponsehandler import send_response

# To genareta the response.
send_response("200", "Success", "This is our data")


```
